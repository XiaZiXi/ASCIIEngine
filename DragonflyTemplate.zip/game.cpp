//
// game.cpp
// 
#define GAME_NAME "Game"
#define VERSION 1.0

// Engine includes.
#include "GameManager.h"
#include "LogManager.h"
#include "ResourceManager.h"
 
// Game includes.

// Function prototypes.
void populateWorld(void);

void loadResources(void);
 
int main(int argc, char *argv[]) {
  df::LogManager &log_manager = df::LogManager::getInstance();

  // Start up game manager.
  df::GameManager &game_manager = df::GameManager::getInstance();
  if (game_manager.startUp())  {
    log_manager.writeLog("Error starting game manager!");
    game_manager.shutDown();
    return 0;
  }

  // Write game version information to logfile.
  log_manager.writeLog("%s, version %0.1f", GAME_NAME, VERSION);

  // Set flush of logfile during development (when done, make false).
  log_manager.setFlush(true);

  loadResources();

  // Setup some objects.
  populateWorld();
 
  // Run game (this blocks until game loop is over).
  game_manager.run();
 
  // Shut everything down.
  game_manager.shutDown();
}

void loadResources(void) {
}
 
// Populate world with some objects.
void populateWorld(void) {
}
